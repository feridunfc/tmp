# src/strategies/__init__.py
from .registry import (
    bootstrap, list_strategies, get_strategy, get_registry,
    register_strategy, register_ml, register_rule, register_hybrid
)

# Paket import edilince stratejileri kaydet (auto + static + discover)
# İsterseniz STRATEGY_BOOTSTRAP=static/auto/both ile davranışı değiştirebilirsiniz.
import os
_mode = os.getenv("STRATEGY_BOOTSTRAP", "both")
try:
    bootstrap(mode=_mode, strict=False)
except Exception:
    # Son bir kez 'both' dene
    bootstrap(mode="both", strict=False)
