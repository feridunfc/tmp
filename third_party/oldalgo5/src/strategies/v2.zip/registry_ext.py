from __future__ import annotations
from typing import Dict, List, Type
from .base import StrategyBase
from .conventional.ma_crossover import MACrossoverStrategy
from .ai.unified_ai import UnifiedAIStrategy
from .hybrid.hybrid_ensemble import HybridEnsembleStrategy

_REG: Dict[str, Type[StrategyBase]] = {
    "ma_crossover": MACrossoverStrategy,
    "ai_unified": UnifiedAIStrategy,
    "hybrid_ensemble": HybridEnsembleStrategy,
}

def register(name: str, cls: Type[StrategyBase]):
    _REG[name] = cls

def list_strategies() -> List[str]:
    return sorted(_REG.keys())

def get_strategy(name: str, **params) -> StrategyBase:
    cls = _REG.get(name)
    if cls is None:
        raise KeyError(f"Strategy '{name}' not found. Available: {list(_REG)}")
    return cls(**params)

def create(name: str, **params) -> StrategyBase:
    return get_strategy(name, **params)
