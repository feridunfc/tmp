
import pandas as pd
from ..registry import register
from ..ai._common import _train_predict_proba, _to_signal
from ...features.basic import make_basic_features
from sklearn.linear_model import LogisticRegression

@register("hb_ai_gate_ma", schema={
    "fast": {"type":"int","min":5,"max":50,"step":1,"default":10},
    "slow": {"type":"int","min":10,"max":200,"step":5,"default":30},
    "threshold": {"type":"float","min":0.45,"max":0.55,"step":0.01,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    px = df["Close"].astype(float)
    fx = max(2, int(p.get("fast", 10)))
    sx = max(fx+1, int(p.get("slow", 30)))
    ma_sig = (px.rolling(fx).mean() > px.rolling(sx).mean()).astype(int)*2 - 1
    prob = _train_predict_proba(LogisticRegression(max_iter=1000), df)
    gate = (prob >= float(p.get("threshold", 0.5))).astype(int)
    sig = (ma_sig.where(gate==1, 0)).fillna(0).astype(int).clip(-1,1)
    return sig.rename("signal")
