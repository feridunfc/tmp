
import pandas as pd, numpy as np
from ..registry import register
from ...features.basic import make_basic_features, target_next_up
from sklearn.linear_model import LogisticRegression

@register("hb_stack_lr_on_signals", schema={
    "base_fast": {"type":"int","min":5,"max":50,"step":1,"default":10},
    "base_slow": {"type":"int","min":10,"max":200,"step":5,"default":30},
    "threshold": {"type":"float","min":0.45,"max":0.55,"step":0.01,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    px = df["Close"].astype(float)
    f = int(p.get("base_fast", 10)); s = int(p.get("base_slow", 30))
    sma_sig = (px.rolling(f).mean() > px.rolling(s).mean()).astype(int)
    rsi = make_basic_features(df)["rsi"]
    feats = pd.DataFrame({"sma_sig":sma_sig, "rsi":rsi}, index=df.index).fillna(0.0)
    y = (px.pct_change().shift(-1) > 0).astype(int).fillna(0)
    clf = LogisticRegression(max_iter=1000)
    clf.fit(feats.iloc[:-1], y.iloc[:-1])
    p1 = clf.predict_proba(feats)[:,1]
    thr = float(p.get("threshold", 0.5))
    sig = ((p1 >= thr).astype(int)*2 - 1)
    return pd.Series(sig, index=df.index, name="signal")
