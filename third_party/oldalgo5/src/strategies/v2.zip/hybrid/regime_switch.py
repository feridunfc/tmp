
import pandas as pd
from ..registry import register
from ...features.basic import make_basic_features

@register("hb_regime_vol_switch", schema={
    "vol_window": {"type":"int","min":10,"max":60,"step":5,"default":20},
    "mom_window": {"type":"int","min":5,"max":60,"step":5,"default":20},
    "z_window": {"type":"int","min":5,"max":60,"step":5,"default":20}
})
def gen(df: pd.DataFrame, p):
    fx = make_basic_features(df)
    vol = fx["vol"]
    thresh = vol.rolling(int(p.get("vol_window",20))).median().ffill().bfill()
    # düşük vol -> momentum; yüksek vol -> meanrev
    mom = df["Close"].pct_change(int(p.get("mom_window",20))).fillna(0.0)
    z = fx["zret20"]
    sig = mom.apply(lambda x: 1 if x>0 else -1)
    mr = (-z).clip(-1,1).apply(lambda v: 1 if v>0 else -1)
    regime = (vol <= thresh).astype(int)  # 1 low-vol, 0 high-vol
    out = sig.where(regime==1, mr)
    return out.rename("signal")
