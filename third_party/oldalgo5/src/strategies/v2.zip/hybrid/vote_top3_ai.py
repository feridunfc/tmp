
import pandas as pd
from ..registry import register
from ...features.basic import make_basic_features, target_next_up
from ..ai._common import _train_predict_proba, _to_signal
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC

@register("hb_vote_top3_ai", schema={
    "threshold": {"type":"float","min":0.45,"max":0.55,"step":0.01,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    thr = float(p.get("threshold", 0.5))
    # 3 farklı modelden oy
    p1 = _train_predict_proba(LogisticRegression(max_iter=1000), df)
    p2 = _train_predict_proba(RandomForestClassifier(n_estimators=200, random_state=42), df)
    p3 = _train_predict_proba(SVC(C=1.0, gamma="scale", probability=True, random_state=42), df)
    prob = (p1 + p2 + p3) / 3.0
    return _to_signal(prob, thr)
