
import pandas as pd, numpy as np
from ..registry import register
from ...features.basic import make_basic_features

@register("hb_weighted_basket", schema={
    "fast": {"type":"int","min":5,"max":50,"step":1,"default":10},
    "slow": {"type":"int","min":10,"max":200,"step":5,"default":30},
    "rsi_low": {"type":"int","min":5,"max":40,"step":1,"default":30},
    "rsi_high": {"type":"int","min":60,"max":95,"step":1,"default":70},
    "w_ma": {"type":"float","min":0.0,"max":1.0,"step":0.1,"default":0.5},
    "w_rsi": {"type":"float","min":0.0,"max":1.0,"step":0.1,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    px = df["Close"].astype(float)
    f = int(p.get("fast", 10)); s = int(p.get("slow", 30))
    ma = (px.rolling(f).mean() > px.rolling(s).mean()).astype(int)*2 - 1
    from ...features.basic import make_basic_features
    rsi = make_basic_features(df)["rsi"]
    rsisig = ((rsi < int(p.get("rsi_low",30))).astype(int) - (rsi > int(p.get("rsi_high",70))).astype(int))
    rsisig = rsisig.replace(0, pd.NA).ffill().fillna(0).clip(-1,1)
    w1 = float(p.get("w_ma",0.5)); w2 = float(p.get("w_rsi",0.5))
    comb = (w1*ma + w2*rsisig)
    sig = comb.apply(lambda v: 1 if v>0 else (-1 if v<0 else 0))
    return sig.rename("signal")
