from __future__ import annotations
import numpy as np
import pandas as pd
from ..base import StrategyBase, ParamField

class HybridEnsembleStrategy(StrategyBase):
    """Filter base strategy signals with a simple meta-heuristic."""
    @classmethod
    def param_schema(cls):
        return [
            ParamField("base_strategy", "select", "ma_crossover", options=["ma_crossover","ai_unified"]),
            ParamField("fast_period", "int", 20, 2, 500),
            ParamField("slow_period", "int", 50, 3, 1000),
            ParamField("lookback", "int", 30, 5, 300),
            ParamField("meta_threshold", "float", 0.6, 0.0, 1.0),
            ParamField("min_confidence","float", 0.45, 0.0, 1.0),
        ]

    def __init__(self, **params):
        self.params = self.validate_params(params)

    def _load_strategy(self, name: str):
        from ..registry_ext import create
        p = dict(self.params)
        return create(name, **p)

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        base = self._load_strategy(self.params.get("base_strategy","ma_crossover"))
        return base.prepare(df)

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        base = self._load_strategy(self.params.get("base_strategy","ma_crossover"))
        base_sig = base.generate_signals(df).astype(float)
        ret = df["close"].pct_change().fillna(0.0)
        z = (ret.rolling(20).mean() / (ret.rolling(20).std().replace(0,np.nan))).fillna(0.0)
        conf = np.tanh(z.abs())  # 0..~1
        min_conf = float(self.params.get("min_confidence", 0.45))
        meta_thr = float(self.params.get("meta_threshold", 0.6))
        final = base_sig.copy()
        final[conf < min_conf] = 0.0
        flip = conf < meta_thr
        final[flip] = -final[flip]
        return final.clip(-1,1)
