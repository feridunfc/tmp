# src/strategies/registry.py
from __future__ import annotations

import importlib
import inspect
import logging
import pkgutil
import traceback
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple, Type

logger = logging.getLogger(__name__)

__all__ = [
    "register_strategy", "register_ml", "register_rule", "register_hybrid",
    "list_strategies", "create", "get_registry", "get_strategy",
    "discover_strategies", "get_strategy_class", "get_param_schema",
    "bootstrap", "StrategyParameters"
]

# --- Base imports (lenient) ---------------------------------------------------
try:
    from strategies.base_strategy import BaseStrategy as AILearningBase
    try:
        from strategies.base_strategy import StrategyParameters as _StrategyParameters
    except Exception:
        _StrategyParameters = Any  # type: ignore
except Exception:
    class AILearningBase:  # type: ignore
        pass
    _StrategyParameters = Any  # type: ignore

try:
    from strategies.base import Strategy as RuleBasedBase
except Exception:
    class RuleBasedBase:  # type: ignore
        pass

StrategyParameters = _StrategyParameters

# --- Import helpers -----------------------------------------------------------
def _import_module_lenient(modpath: str):
    try:
        return importlib.import_module(modpath)
    except ModuleNotFoundError:
        if modpath.startswith("src."):
            alt = modpath[len("src."):]
        else:
            alt = "src." + modpath
        return importlib.import_module(alt)

def _import_from_path(spec: str):
    """'pkg.mod:Name' -> obj (yoksa None)."""
    modpath, _, name = spec.partition(":")
    if not modpath or not name:
        return None
    try:
        module = _import_module_lenient(modpath)
        return getattr(module, name, None)
    except Exception as e:
        logger.info("static bind skipped: %s (%s)", spec, e)
        return None

# --- Registry (decorator) -----------------------------------------------------
STRATEGY_REGISTRY: Dict[str, Any] = {}

def register_strategy(name: str):
    def deco(cls_or_fn):
        STRATEGY_REGISTRY[name] = cls_or_fn
        logger.debug("strategy registered: %s -> %s", name, getattr(cls_or_fn, "__name__", str(cls_or_fn)))
        return cls_or_fn
    return deco

# Backward aliases
def register_ml(name: str):     return register_strategy(name)
def register_rule(name: str):   return register_strategy(name)
def register_hybrid(name: str): return register_strategy(name)

def list_strategies() -> List[str]:
    return sorted(STRATEGY_REGISTRY.keys())

def create(name: str, *args, **kwargs):
    factory = STRATEGY_REGISTRY.get(name)
    if not factory:
        raise KeyError(f"Strategy '{name}' not found. Available: {list_strategies()}")
    return factory(*args, **kwargs)

# --- Discovery / static binds -------------------------------------------------
def _bootstrap_autodiscovery() -> int:
    try:
        from strategies.plugins.auto_register import bootstrap as _auto
    except Exception as e:
        logger.debug("auto_register not available: %s", e)
        return 0
    before = len(STRATEGY_REGISTRY)
    gained = _auto()
    logger.info("auto_discovery registered +%d strategies (total=%d)", gained, len(STRATEGY_REGISTRY))
    return len(STRATEGY_REGISTRY) - before

_STATIC_BINDINGS: List[Tuple[str, str]] = [
    # Rule-based (en yaygınlar)
    ("rb_atr_breakout",        "strategies.rule_based.atr_breakout:ATRBreakout"),
    ("rb_ma_crossover",        "strategies.rule_based.ma_crossover:MACrossover"),
    ("rb_breakout",            "strategies.rule_based.breakout:Breakout"),
    ("rb_rsi_threshold",       "strategies.rule_based.rsi_threshold:RSIThreshold"),
    ("rb_macd",                "strategies.rule_based.macd_signal:MACDSignal"),
    ("rb_bollinger_reversion", "strategies.rule_based.bollinger_reversion:BollingerReversion"),
    ("rb_donchian_breakout",   "strategies.rule_based.donchian_breakout:DonchianBreakout"),
    ("rb_stochastic",          "strategies.rule_based.stochastic_osc:StochasticOsc"),
    ("rb_adx_trend",           "strategies.rule_based.adx_trend:ADXTrend"),
    ("rb_vol_breakout_atr",    "strategies.rule_based.vol_breakout_atr:VolatilityBreakoutATR"),
    ("rb_ichimoku",            "strategies.rule_based.ichimoku:IchimokuTrend"),

    # AI (varsa projede)
    ("ai_random_forest",   "strategies.ai.random_forest:RandomForestStrategy"),
    ("ai_extra_trees",     "strategies.ai.extra_trees:ExtraTreesStrategy"),
    ("ai_logistic",        "strategies.ai.logistic:LogisticStrategy"),
    ("ai_svm",             "strategies.ai.svm:SVMStrategy"),
    ("ai_knn",             "strategies.ai.knn:KNNStrategy"),
    ("ai_xgboost",         "strategies.ai.xgboost_strict:XGBoostStrictStrategy"),
    ("ai_lightgbm",        "strategies.ai.lightgbm:LightGBMStrategy"),
    ("ai_catboost",        "strategies.ai.catboost:CatBoostStrategy"),
    ("ai_naive_bayes",     "strategies.ai.naive_bayes:NaiveBayesStrategy"),
    ("ai_lstm",            "strategies.ai.lstm:LSTMStrategy"),
    ("ai_online_sgd",      "strategies.ai.online_sgd:OnlineSGDStrategy"),

    # Hybrid (opsiyonel)
    ("hy_ensemble_voter",   "strategies.hybrid.ensemble_voter:EnsembleVoter"),
    ("hy_regime_switcher",  "strategies.hybrid.regime_switcher:RegimeSwitcher"),
    ("hy_weighted_ensemble","strategies.hybrid.weighted_ensemble:WeightedEnsemble"),
    ("hy_rule_filter_ai",   "strategies.hybrid.rule_filter_ai:RuleFilterAI"),
]

_GEN_NAME_CANDIDATES = (
    "generate_signals", "generate", "gen", "signal", "signals",
    "predict_signals", "predict", "predict_proba"
)
_PREP_NAME_CANDIDATES = ("prepare",)

def _bootstrap_static_bindings() -> int:
    added = 0
    for key, spec in _STATIC_BINDINGS:
        if key in STRATEGY_REGISTRY:
            continue
        obj = _import_from_path(spec)

        # Sınıf bulunamazsa aynı modülde serbest fonksiyon dene
        if obj is None:
            modpath, _, _ = spec.partition(":")
            for alt in (":gen", ":generate_signals", ":generate"):
                fn = _import_from_path(modpath + alt)
                if callable(fn):
                    obj = fn
                    break

        if obj is None:
            continue
        STRATEGY_REGISTRY.setdefault(key, obj)
        added += 1

    if added:
        logger.info("static bindings registered +%d (total=%d)", added, len(STRATEGY_REGISTRY))
    return added

# --- StrategySpec / discovery -------------------------------------------------
@dataclass(frozen=True)
class StrategySpec:
    qualified_name: str
    display_name: str
    family: str
    module: str
    cls: Type
    param_schema: Optional[Type[Any]]

def _looks_like_strategy_class(obj: Any) -> bool:
    if not inspect.isclass(obj) or inspect.isabstract(obj):
        return False
    if getattr(obj, "is_strategy", False):
        return True
    try:
        if issubclass(obj, (AILearningBase, RuleBasedBase)):
            return True
    except Exception:
        pass
    has_train = callable(getattr(obj, "fit", None)) or callable(getattr(obj, "train", None))
    has_pred = callable(getattr(obj, "predict", None)) or callable(getattr(obj, "predict_proba", None))
    return has_train and has_pred

def discover_strategies() -> Dict[str, StrategySpec]:
    try:
        root = _import_module_lenient("strategies")
    except Exception:
        root = _import_module_lenient("src.strategies")

    results: Dict[str, StrategySpec] = {}
    errors: Dict[str, str] = {}
    skip_contains = (".features", ".strategy_factory", ".registry", ".adapters", ".base", ".hybrid_v1",
                     ".ai.logreg_strategy", ".ai.rf_strategy")

    candidates: List[str] = []
    if hasattr(root, "__path__"):
        for mi in pkgutil.walk_packages(root.__path__, root.__name__ + "."):
            name = mi.name
            if any(s in name for s in skip_contains):
                continue
            candidates.append(name)

    if not candidates:
        for pkg in ("strategies.rule_based", "strategies.ai", "strategies.hybrid",
                    "src.strategies.rule_based", "src.strategies.ai", "src.strategies.hybrid"):
            try:
                mod = _import_module_lenient(pkg)
                if hasattr(mod, "__path__"):
                    for mi in pkgutil.walk_packages(mod.__path__, mod.__name__ + "."):
                        name = mi.name
                        if any(s in name for s in skip_contains):
                            continue
                        candidates.append(name)
            except Exception as e:
                errors[pkg] = f"{type(e).__name__}: {e}"

    for name in candidates:
        try:
            m = _import_module_lenient(name)
            for _, obj in inspect.getmembers(m, _looks_like_strategy_class):
                qn = f"{obj.__module__}.{obj.__name__}"
                mod = obj.__module__ or ""
                if ".ai." in mod: family = "ai"
                elif ".rule_based." in mod: family = "rule_based"
                elif ".hybrid." in mod: family = "hybrid"
                else: family = "conventional"

                spec = StrategySpec(
                    qualified_name=qn,
                    display_name=getattr(obj, "name", getattr(obj, "display_name", obj.__name__)),
                    family=family, module=obj.__module__, cls=obj,
                    param_schema=getattr(obj, "ParamSchema", None),
                )
                results[qn] = spec
        except Exception as e:
            errors[name] = f"{type(e).__name__}: {e}\n{traceback.format_exc(limit=1)}"

    discover_strategies.errors = errors
    return results

# --- Helpers to adapt to UI (gen/prep) ---------------------------------------
def _infer_family_from_module(mod: str) -> str:
    if ".ai." in mod: return "ai"
    if ".rule_based." in mod: return "rule_based"
    if ".hybrid." in mod: return "hybrid"
    return "conventional"

def _filter_kwargs(fn: Callable, params: Dict[str, Any]) -> Dict[str, Any]:
    try:
        sig = inspect.signature(fn)
        return {k: v for k, v in params.items() if k in sig.parameters}
    except Exception:
        return params

def _module_level_callable(target: Any, names: Tuple[str, ...]) -> Optional[Callable]:
    """Sınıfın modülünde isim adaylarından birini bul (gen/prepare için)."""
    try:
        module = _import_module_lenient(getattr(target, "__module__", ""))
        for nm in names:
            fn = getattr(module, nm, None)
            if callable(fn):
                return fn
    except Exception:
        pass
    return None

def _make_gen_callable(target: Any) -> Callable[[Any], Any]:
    # 1) Class → instance method
    if inspect.isclass(target):
        def _gen(df, **params):
            inst_kwargs = _filter_kwargs(target, params)
            try:
                inst = target(**inst_kwargs)
            except TypeError:
                inst = target()
            # sınıf içi isim adayları
            for name in _GEN_NAME_CANDIDATES:
                meth = getattr(inst, name, None)
                if callable(meth):
                    try:
                        return meth(df, **params)
                    except TypeError:
                        return meth(df)
            # 2) Fallback: module-level gen/generate...
            fn = _module_level_callable(target, _GEN_NAME_CANDIDATES)
            if callable(fn):
                try:
                    return fn(df, **params)
                except TypeError:
                    return fn(df)
            raise KeyError(f"{target.__name__}: uygun sinyal metodu/fonksiyonu bulunamadı")
        return _gen

    # 3) Callable target (function/factory)
    if callable(target):
        def _gen(df, **params):
            try:
                # doğrudan sinyal fonksiyonu olabilir
                return target(df, **params)
            except TypeError:
                # factory olabilir -> instance
                inst = target(**_filter_kwargs(target, params))
                for name in _GEN_NAME_CANDIDATES:
                    meth = getattr(inst, name, None)
                    if callable(meth):
                        try:
                            return meth(df, **params)
                        except TypeError:
                            return meth(df)
                fn = _module_level_callable(inst, _GEN_NAME_CANDIDATES) or _module_level_callable(target, _GEN_NAME_CANDIDATES)
                if callable(fn):
                    try:
                        return fn(df, **params)
                    except TypeError:
                        return fn(df)
                raise KeyError("Factory çıktısında sinyal metodu yok")
        return _gen

    raise TypeError(f"Unsupported strategy target: {type(target)}")

def _make_prep_callable(target: Any) -> Optional[Callable[[Any], Any]]:
    # Class.prepare
    if inspect.isclass(target):
        if callable(getattr(target, "prepare", None)):
            def _prep(df, **params):
                try:
                    inst = target(**_filter_kwargs(target, params))
                except TypeError:
                    inst = target()
                try:
                    return inst.prepare(df, **params)
                except TypeError:
                    return inst.prepare(df)
            return _prep
        # module-level prepare
        fn = _module_level_callable(target, _PREP_NAME_CANDIDATES)
        if callable(fn):
            def _prep(df, **params):
                try:
                    return fn(df, **params)
                except TypeError:
                    return fn(df)
            return _prep
        return None

    # Function/factory: export prepare?
    prep_fn = getattr(target, "prepare", None)
    if callable(prep_fn):
        def _prep(df, **params):
            try:
                return prep_fn(df, **params)
            except TypeError:
                return prep_fn(df)
        return _prep

    # factory'nin modülünde prepare?
    fn = _module_level_callable(target, _PREP_NAME_CANDIDATES)
    if callable(fn):
        def _prep(df, **params):
            try:
                return fn(df, **params)
            except TypeError:
                return fn(df)
        return _prep
    return None

def _display_name_for(target: Any, key: str) -> str:
    return getattr(target, "display_name", getattr(target, "name", key.replace("_", " ").title()))

def _family_for(target: Any) -> str:
    mod = getattr(target, "__module__", "") or ""
    fam = getattr(target, "family", None)
    return fam or _infer_family_from_module(mod)

def _schema_for(target: Any) -> Any:
    return getattr(target, "ParamSchema", getattr(target, "param_schema", None))

def _build_entry(key: str, target: Any) -> Dict[str, Any]:
    return {
        "factory": target,
        "class": target if inspect.isclass(target) else None,
        "display_name": _display_name_for(target, key),
        "family": _family_for(target),
        "schema": _schema_for(target),
        "gen": _make_gen_callable(target),
        "prep": _make_prep_callable(target),
        "version": getattr(target, "version", None),
        "module": getattr(target, "__module__", None),
        "qualified": f"{getattr(target, '__module__', '?')}.{getattr(target, '__name__', key)}",
    }

# --- Public API ---------------------------------------------------------------
def _ensure_bootstrapped() -> None:
    if not STRATEGY_REGISTRY:
        try:
            bootstrap(mode="auto", strict=False)
        except Exception:
            bootstrap(mode="static", strict=False)

def get_strategy(name: str):
    _ensure_bootstrapped()
    if name in STRATEGY_REGISTRY:
        return STRATEGY_REGISTRY[name]
    if ":" in name:
        cls = _import_from_path(name)
        if cls is not None:
            return cls
    try:
        return get_strategy_class(name)
    except Exception:
        pass
    raise KeyError(f"Strategy '{name}' not found. Available keys: {list_strategies()}")

def get_registry():
    _ensure_bootstrapped()
    entries: Dict[str, Dict[str, Any]] = {k: _build_entry(k, v) for k, v in STRATEGY_REGISTRY.items()}

    def _sort_key(item: Tuple[str, Dict[str, Any]]):
        k, d = item
        return (d.get("family", "zzz"), d.get("display_name", k))

    ordered = sorted(entries.items(), key=_sort_key)
    order_keys = [(k, d["display_name"]) for k, d in ordered]
    return entries, order_keys

def get_strategy_class(qualified_name: str) -> Type:
    module_name, class_name = qualified_name.rsplit(".", 1)
    module = _import_module_lenient(module_name)
    return getattr(module, class_name)

def get_param_schema(qualified_name: str) -> Type[Any]:
    cls = get_strategy_class(qualified_name)
    return getattr(cls, "ParamSchema", StrategyParameters)

def bootstrap(mode: str = "auto", strict: bool = False) -> int:
    before = len(STRATEGY_REGISTRY)
    gained = 0
    if mode in ("auto", "both"):
        gained += _bootstrap_autodiscovery()
    if mode in ("static", "both") or (mode == "auto" and gained == 0):
        gained += _bootstrap_static_bindings()
    total = len(STRATEGY_REGISTRY)
    if strict and total == 0:
        raise RuntimeError("No strategies registered. Check optional deps and paths.")
    logger.debug("bootstrap done: +%d (total=%d)", total - before, total)
    return total - before
