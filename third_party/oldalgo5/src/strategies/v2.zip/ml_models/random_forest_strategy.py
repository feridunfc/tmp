from __future__ import annotations
import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple
from sklearn.ensemble import RandomForestClassifier
from ..base_ml_strategy import BaseMLStrategy

class RandomForestStrategy(BaseMLStrategy):
    NAME = "ml_random_forest"

    def create_model(self, **params) -> RandomForestClassifier:
        defaults = dict(n_estimators=200, max_depth=None, min_samples_split=2, random_state=42, n_jobs=-1)
        defaults.update(params)
        return RandomForestClassifier(**defaults)

    def prepare_features(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
        data = df.copy()
        # Support both Close/close capitalization
        close = data['Close'] if 'Close' in data.columns else data['close']
        data['ret'] = close.pct_change()
        data['sma_10'] = close.rolling(10).mean()
        data['sma_20'] = close.rolling(20).mean()
        data['sma_diff'] = data['sma_10'] - data['sma_20']
        data['vol_20'] = data['ret'].rolling(20).std()
        # simple RSI
        delta = close.diff()
        gain = (delta.where(delta > 0, 0.0)).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0.0)).rolling(14).mean()
        rs = gain / (loss.replace(0, np.nan))
        data['rsi'] = 100 - (100 / (1 + rs))
        # target: next bar up
        data['target'] = (close.shift(-1) > close).astype(int)
        data = data.replace([np.inf, -np.inf], np.nan).dropna()
        X = data[['ret','sma_10','sma_20','sma_diff','vol_20','rsi']]
        y = data['target']
        return X, y

    @staticmethod
    def schema() -> Dict[str, Any]:
        s = BaseMLStrategy.default_schema().copy()
        s.update({
            'n_estimators': {'type':'int','default':200,'min':50,'max':600,'step':50},
            'max_depth': {'type':'int','default':10,'min':3,'max':30,'step':1},
            'min_samples_split': {'type':'int','default':2,'min':2,'max':20,'step':1},
        })
        return s
