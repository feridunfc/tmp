from __future__ import annotations

def proba_to_signal(p: float, th: float = 0.6) -> int:
    try:
        p = float(p)
    except Exception:
        return 0
    if p >= th:
        return 1
    if p <= 1.0 - th:
        return -1
    return 0
