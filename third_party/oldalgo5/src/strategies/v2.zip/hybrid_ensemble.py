from __future__ import annotations
import pandas as pd
import numpy as np
from ..contracts import register_strategy

@register_strategy
class HybridEnsemble:
    name = "hybrid_ensemble"
    def __init__(self, weights: dict[str,float] | None = None, regime_col: str = "regime_vol_state"):
        self.params = {"weights": weights or {"ma_crossover":0.5, "ai_unified":0.5}, "regime_col": regime_col}

    def prepare(self, df: pd.DataFrame)->pd.DataFrame:
        return df

    def generate_signals(self, df: pd.DataFrame)->pd.Series:
        acc = None
        for k, w in self.params["weights"].items():
            col = f"signal_{k}"
            if col not in df.columns:
                continue
            s = df[col].astype(float).fillna(0.0) * float(w)
            acc = s if acc is None else (acc + s)
        if acc is None:
            return pd.Series(0, index=df.index, name="signal_hybrid_ensemble")
        if self.params["regime_col"] in df.columns:
            hv = (df[self.params["regime_col"]] >= 1).astype(int)
            acc = acc.where(hv==0, acc * 0.6)
        sig = pd.Series(np.sign(acc), index=df.index).shift(1).fillna(0).astype(int)
        return sig.rename("signal_hybrid_ensemble")
