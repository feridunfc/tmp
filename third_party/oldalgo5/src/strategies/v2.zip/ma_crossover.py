from __future__ import annotations
import pandas as pd
from ..contracts import register_strategy

@register_strategy
class MA_Crossover:
    name = "ma_crossover"
    def __init__(self, short:int=10, long:int=30):
        self.params = {"short": short, "long": long}

    def prepare(self, df: pd.DataFrame)->pd.DataFrame:
        out = df.copy()
        s = max(2, int(self.params["short"])); l = max(s+1, int(self.params["long"]))
        out["ma_s"] = out["close"].rolling(s).mean()
        out["ma_l"] = out["close"].rolling(l).mean()
        return out

    def generate_signals(self, df: pd.DataFrame)->pd.Series:
        s = (df["ma_s"] > df["ma_l"]).astype(int) - (df["ma_s"] < df["ma_l"]).astype(int)
        return s.shift(1).fillna(0).astype(int).rename("signal_ma_crossover")
