from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import pandas as pd

@dataclass
class ParamField:
    name: str
    type: str = "float"   # int|float|select|bool|text
    default: Any = 0.0
    min: Optional[float] = None
    max: Optional[float] = None
    options: Optional[List[Any]] = None
    log: bool = False

class StrategyBase:
    """Minimal standard interface used by UI/HPO layers."""
    @classmethod
    def param_schema(cls) -> List[ParamField]:
        return []

    def validate_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Clamp numeric to [min,max], ensure select in options; apply defaults."""
        out: Dict[str, Any] = {}
        for f in self.param_schema():
            v = params.get(f.name, f.default)
            if f.type in ("int","float"):
                try:
                    v = int(v) if f.type=="int" else float(v)
                except Exception:
                    v = f.default
                if f.min is not None and v < f.min:
                    v = f.min
                if f.max is not None and v > f.max:
                    v = f.max
            elif f.type == "select" and f.options:
                if v not in f.options:
                    v = f.options[0]
            elif f.type == "bool":
                v = bool(v)
            out[f.name] = v
        # pass-through extras
        for k,v in params.items():
            if k not in out:
                out[k] = v
        return out

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        return df

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:  # -1..1
        raise NotImplementedError
