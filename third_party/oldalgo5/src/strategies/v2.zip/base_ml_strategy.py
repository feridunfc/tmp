from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Tuple
import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator
import joblib
from datetime import datetime

class BaseMLStrategy(ABC):
    """Base class for ML/Hybrid strategies with a unified interface."""
    def __init__(self, strategy_id: str, **kwargs):
        self.strategy_id = strategy_id
        self.model: BaseEstimator | None = None
        self.is_trained: bool = False
        self.training_metrics: Dict[str, float] = {}
        self.feature_columns: List[str] = []
        self.target_column: str = 'target'
        self.params: Dict[str, Any] = dict(kwargs)
        self.metadata = {
            'strategy_type': 'ml',
            'created_at': datetime.now().isoformat(timespec='seconds'),
            'last_trained': None,
            'version': '1.0'
        }

    @abstractmethod
    def create_model(self, **params) -> BaseEstimator:
        pass

    @abstractmethod
    def prepare_features(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
        """Return (X, y) with aligned index. Must drop NaNs inside."""
        pass

    def fit(self, df: pd.DataFrame, **fit_params) -> Dict[str, float]:
        X, y = self.prepare_features(df)
        self.feature_columns = list(X.columns)
        self.model = self.create_model(**self.params)
        self.model.fit(X, y, **fit_params)
        self.training_metrics = self._calc_train_metrics(X, y)
        self.is_trained = True
        self.metadata['last_trained'] = datetime.now().isoformat(timespec='seconds')
        return self.training_metrics

    def predict_proba(self, df: pd.DataFrame) -> np.ndarray:
        if not self.is_trained:
            raise ValueError("Model is not trained; call fit() first.")
        X, _ = self.prepare_features(df)
        if hasattr(self.model, 'predict_proba'):
            return self.model.predict_proba(X)[:, 1]
        # fallback: decision_function -> sigmoid
        if hasattr(self.model, 'decision_function'):
            z = self.model.decision_function(X)
            return 1.0 / (1.0 + np.exp(-z))
        # last resort: predict (0/1)
        return self.model.predict(X).astype(float)

    def generate_signals(self, df: pd.DataFrame, *, threshold: float = 0.5, neutral_band: float = 0.1) -> pd.Series:
        p = self.predict_proba(df)
        hi = threshold + neutral_band/2.0
        lo = threshold - neutral_band/2.0
        sig = np.where(p >= hi, 1.0, np.where(p <= lo, -1.0, 0.0))
        return pd.Series(sig, index=df.index, name='signal')

    def _calc_train_metrics(self, X: pd.DataFrame, y: pd.Series) -> Dict[str, float]:
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
        if hasattr(self.model, 'predict_proba'):
            proba = self.model.predict_proba(X)[:, 1]
        else:
            # degrade gracefully
            if hasattr(self.model, 'decision_function'):
                z = self.model.decision_function(X)
                proba = 1.0 / (1.0 + np.exp(-z))
            else:
                proba = self.model.predict(X).astype(float)
        pred = (proba >= 0.5).astype(int)
        out = {
            'accuracy': float(accuracy_score(y, pred)),
            'precision': float(precision_score(y, pred, zero_division=0)),
            'recall': float(recall_score(y, pred, zero_division=0)),
            'f1': float(f1_score(y, pred, zero_division=0)),
        }
        try:
            out['roc_auc'] = float(roc_auc_score(y, proba))
        except Exception:
            out['roc_auc'] = float('nan')
        # Feature importance (if any)
        try:
            if hasattr(self.model, 'feature_importances_'):
                out['feature_importance_sum'] = float(np.sum(self.model.feature_importances_))
        except Exception:
            pass
        return out

    def save_model(self, path: str) -> None:
        joblib.dump({
            'model': self.model,
            'metadata': self.metadata,
            'training_metrics': self.training_metrics,
            'feature_columns': self.feature_columns,
            'target_column': self.target_column,
            'params': self.params,
        }, path)

    def load_model(self, path: str) -> None:
        obj = joblib.load(path)
        self.model = obj['model']
        self.metadata = obj.get('metadata', self.metadata)
        self.training_metrics = obj.get('training_metrics', {})
        self.feature_columns = obj.get('feature_columns', [])
        self.target_column = obj.get('target_column', 'target')
        self.params = obj.get('params', {})
        self.is_trained = True

    @staticmethod
    def default_schema() -> Dict[str, Any]:
        return {
            'threshold': {'type': 'float', 'default': 0.5, 'min': 0.3, 'max': 0.7, 'step': 0.05},
            'neutral_band': {'type': 'float', 'default': 0.1, 'min': 0.05, 'max': 0.3, 'step': 0.05},
        }
