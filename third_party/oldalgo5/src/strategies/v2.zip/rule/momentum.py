
import pandas as pd
from ..registry import register
@register("rb_momentum", schema={"window":{"type":"int","min":5,"max":60,"step":5,"default":20}})
def gen(df, p):
    w = int(p.get("window",20))
    mom = df["Close"].pct_change(w).fillna(0.0)
    sig = mom.apply(lambda x: 1 if x>0 else -1)
    return sig.rename("signal")
