
import pandas as pd, numpy as np
from ..registry import register
from ...features.basic import make_basic_features

@register("rb_rsi_meanrev", schema={
    "period": {"type":"int","min":5,"max":30,"step":1,"default":14},
    "low": {"type":"int","min":5,"max":40,"step":1,"default":30},
    "high": {"type":"int","min":60,"max":95,"step":1,"default":70}
})
def gen(df: pd.DataFrame, p):
    fx = make_basic_features(df)
    rsi = fx["rsi"]
    low = int(p.get("low", 30)); high = int(p.get("high", 70))
    sig = ((rsi < low).astype(int) - (rsi > high).astype(int))
    # convert {-1,0,1} to {-1,1} by carrying last non-zero
    sig = sig.replace(0, pd.NA).ffill().fillna(0).clip(-1,1)
    return sig.rename("signal")
