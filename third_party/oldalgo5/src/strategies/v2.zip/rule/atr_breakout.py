
import pandas as pd
from ..registry import register
from ...features.basic import atr
@register("rb_atr_breakout", schema={"n":{"type":"int","min":7,"max":28,"step":1,"default":14},"k":{"type":"float","min":1.0,"max":4.0,"step":0.5,"default":2.0}})
def gen(df, p):
    px = df["Close"].astype(float)
    a = atr(df, int(p.get("n",14)))
    up = px.shift(1) + float(p.get("k",2.0))*a
    lo = px.shift(1) - float(p.get("k",2.0))*a
    sig = ((px > up).astype(int) - (px < lo).astype(int))
    sig = sig.replace(0, pd.NA).ffill().fillna(0).clip(-1,1)
    return sig.rename("signal")
