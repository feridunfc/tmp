
import pandas as pd
from ..registry import register
@register("rb_rsi_meanrev", schema={"period":{"type":"int","min":5,"max":30,"step":1,"default":14},"low":{"type":"int","min":5,"max":40,"step":1,"default":30},"high":{"type":"int","min":60,"max":95,"step":1,"default":70}})
def gen(df, p):
    px = df["Close"].astype(float)
    r = px.pct_change().rolling(int(p.get("period",14))).std().bfill().fillna(0.0) # proxy
    low = int(p.get("low",30)); high = int(p.get("high",70))
    sig = ((r<r.quantile(low/100))).astype(int) - ((r>r.quantile(high/100))).astype(int)
    sig = sig.replace(0, pd.NA).ffill().fillna(0).clip(-1,1)
    return sig.rename("signal")
