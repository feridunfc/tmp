
import pandas as pd, numpy as np
from ..registry import register
@register("rb_psar", schema={"af":{"type":"float","min":0.01,"max":0.2,"step":0.01,"default":0.02},"af_max":{"type":"float","min":0.1,"max":0.5,"step":0.05,"default":0.2}})
def gen(df, p):
    high, low = df["High"].values, df["Low"].values
    af = float(p.get("af",0.02)); af_max = float(p.get("af_max",0.2))
    bull = True
    ep = low[0]; sar = low[0]; acc=af
    psar = []
    for i in range(len(high)):
        psar.append(sar)
        if bull:
            sar = sar + acc*(ep - sar)
            if high[i] > ep:
                ep = high[i]; acc = min(af_max, acc + af)
            if low[i] < sar:
                bull = False; sar = ep; ep = low[i]; acc = af
        else:
            sar = sar + acc*(ep - sar)
            if low[i] < ep:
                ep = low[i]; acc = min(af_max, acc + af)
            if high[i] > sar:
                bull = True; sar = ep; ep = high[i]; acc = af
    ps = pd.Series(psar, index=df.index)
    sig = (df["Close"] > ps).astype(int)*2 - 1
    return sig.rename("signal")
