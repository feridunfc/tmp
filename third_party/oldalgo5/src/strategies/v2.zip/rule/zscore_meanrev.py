
import pandas as pd
from ..registry import register
from ...features.basic import make_basic_features
@register("rb_zscore_meanrev", schema={"window":{"type":"int","min":10,"max":60,"step":5,"default":20},"th":{"type":"float","min":0.5,"max":3.0,"step":0.1,"default":1.0}})
def gen(df, p):
    fx = make_basic_features(df)
    z = fx["zret20"]
    th = float(p.get("th",1.0))
    sig = ((z < -th).astype(int) - (z > th).astype(int))
    sig = sig.replace(0, pd.NA).ffill().fillna(0).clip(-1,1)
    return sig.rename("signal")
