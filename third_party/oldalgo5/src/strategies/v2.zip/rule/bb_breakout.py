
import pandas as pd
from ..registry import register
from ...features.basic import bbands

@register("rb_bb_breakout", schema={
    "period": {"type":"int","min":10,"max":40,"step":2,"default":20},
    "k": {"type":"float","min":1.0,"max":3.0,"step":0.5,"default":2.0}
})
def gen(df: pd.DataFrame, p):
    px = df["Close"].astype(float)
    n = int(p.get("period", 20)); k = float(p.get("k", 2.0))
    m, up, lo = bbands(px, n=n, k=k)
    sig = ((px > up).astype(int) - (px < lo).astype(int))
    sig = sig.replace(0, pd.NA).ffill().fillna(0).clip(-1,1)
    return sig.rename("signal")
