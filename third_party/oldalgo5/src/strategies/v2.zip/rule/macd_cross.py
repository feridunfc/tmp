
import pandas as pd
from ..registry import register
from ...features.basic import macd
@register("rb_macd_cross", schema={"fast":{"type":"int","min":6,"max":20,"step":1,"default":12},"slow":{"type":"int","min":10,"max":40,"step":1,"default":26},"signal":{"type":"int","min":4,"max":18,"step":1,"default":9}})
def gen(df, p):
    px = df["Close"].astype(float)
    m, s, h = macd(px, fast=int(p.get("fast",12)), slow=int(p.get("slow",26)), signal=int(p.get("signal",9)))
    sig = (m > s).astype(int)*2 - 1
    return sig.rename("signal")
