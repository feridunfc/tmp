
import pandas as pd
from ..registry import register
from ...features.basic import make_basic_features

@register("rb_sma_crossover", schema={
    "fast": {"type":"int","min":3,"max":50,"step":1,"default":10},
    "slow": {"type":"int","min":5,"max":200,"step":5,"default":30}
})
def gen(df: pd.DataFrame, p):
    fx = max(2, int(p.get("fast", 10)))
    sx = max(fx+1, int(p.get("slow", 30)))
    px = df["Close"].astype(float)
    fast = px.rolling(fx, min_periods=fx//2).mean()
    slow = px.rolling(sx, min_periods=sx//2).mean()
    sig = (fast > slow).astype(int)*2 - 1
    return sig.rename("signal")
