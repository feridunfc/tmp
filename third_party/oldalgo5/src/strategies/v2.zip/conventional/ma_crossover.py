import pandas as pd

class SMACrossover:
    def __init__(self, fast: int = 10, slow: int = 20):
        self.fast = fast
        self.slow = slow

    def param_schema(self):
        return [
            {"name": "fast", "type": "int", "default": 10, "min": 2, "max": 500},
            {"name": "slow", "type": "int", "default": 20, "min": 2, "max": 1000},
        ]

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        # 🔑 TÜM KOLONLARI KÜÇÜK HARFE ÇEVİR
        out.columns = [str(c).strip().lower() for c in out.columns]
        out["sma_fast"] = out["close"].rolling(self.fast).mean()
        out["sma_slow"] = out["close"].rolling(self.slow).mean()
        return out

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        d = df.copy()
        d.columns = [str(c).strip().lower() for c in d.columns]
        signal = pd.Series(0, index=d.index)
        signal[d["sma_fast"] > d["sma_slow"]] = 1
        signal[d["sma_fast"] < d["sma_slow"]] = -1
        return signal
