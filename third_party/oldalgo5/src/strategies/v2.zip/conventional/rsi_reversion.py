# ... imports ...
import pandas as pd

def rsi(series: pd.Series, period: int) -> pd.Series:
    # mevcut rsi fonksiyonun varsa dokunma
    ...

class RSIReversion:
    def __init__(self, period: int = 14, lower: float = 30, upper: float = 70):
        self.period = period
        self.lower = lower
        self.upper = upper

    def param_schema(self):
        return [
            {"name": "period", "type": "int", "default": 14, "min": 2, "max": 200},
            {"name": "lower", "type": "float", "default": 30.0, "min": 0.0, "max": 50.0},
            {"name": "upper", "type": "float", "default": 70.0, "min": 50.0, "max": 100.0},
        ]

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        # 🔑 TÜM KOLONLARI KÜÇÜK HARFE ÇEVİR
        out.columns = [str(c).strip().lower() for c in out.columns]
        # Artık "close" garantide
        out["rsi"] = rsi(out["close"], self.period)
        return out

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        # prepare çağrıldı varsayıyoruz; yine de emniyet için:
        d = df.copy()
        d.columns = [str(c).strip().lower() for c in d.columns]
        s = pd.Series(0, index=d.index)
        s[d["rsi"] < self.lower] = 1
        s[d["rsi"] > self.upper] = -1
        return s
