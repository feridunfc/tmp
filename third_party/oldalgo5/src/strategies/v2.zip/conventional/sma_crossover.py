from __future__ import annotations
import pandas as pd
from typing import List

class _F:
    def __init__(self, name, type, default=None, options=None):
        self.name, self.type, self.default, self.options = name, type, default, options

def sma(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window).mean()

@staticmethod
def _default_schema() -> List[_F]:
    return [_F("fast","int",10), _F("slow","int",30)]

from ..registry import register

@register("sma_crossover")
class SMACrossoverStrategy:
    def __init__(self, fast: int = 10, slow: int = 30):
        self.fast = int(fast); self.slow = int(slow)

    @staticmethod
    def param_schema():
        return [ _F("fast","int",10), _F("slow","int",30) ]

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out["sma_fast"] = out["Close"].rolling(self.fast).mean()
        out["sma_slow"] = out["Close"].rolling(self.slow).mean()
        return out

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        cross_up = (df["sma_fast"] > df["sma_slow"]) & (df["sma_fast"].shift(1) <= df["sma_slow"].shift(1))
        cross_dn = (df["sma_fast"] < df["sma_slow"]) & (df["sma_fast"].shift(1) >= df["sma_slow"].shift(1))
        sig = pd.Series(0, index=df.index)
        sig = sig.where(~cross_up, 1)
        sig = sig.where(~cross_dn, -1)
        sig = sig.ffill().fillna(0).astype(int)
        sig.name = "signal"
        return sig
