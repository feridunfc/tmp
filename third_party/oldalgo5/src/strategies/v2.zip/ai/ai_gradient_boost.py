
import pandas as pd
from ..registry import register
from ._common import _train_predict_proba, _to_signal
from sklearn.ensemble import GradientBoostingClassifier

def make_model(p):
    return GradientBoostingClassifier(n_estimators=int(p.get('n_estimators',200)), learning_rate=float(p.get('learning_rate',0.05)), max_depth=int(p.get('max_depth',3)))

@register("ai_gradient_boost", schema={"n_estimators": {"type":"int","min":50,"max":400,"step":50,"default":200},
    "learning_rate": {"type":"float","min":0.01,"max":0.3,"step":0.01,"default":0.05},
    "max_depth": {"type":"int","min":2,"max":6,"step":1,"default":3},

    "threshold": {"type":"float","min":0.4,"max":0.6,"step":0.02,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    thr = float(p.get("threshold", 0.5))
    model = make_model(p)
    prob = _train_predict_proba(model, df)
    return _to_signal(prob, thr)
