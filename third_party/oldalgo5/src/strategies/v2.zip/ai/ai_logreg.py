
import pandas as pd
from ..registry import register
from ._common import _train_predict_proba, _to_signal
from sklearn.linear_model import LogisticRegression

def make_model(p):
    return LogisticRegression(max_iter=1000)

@register("ai_logreg", schema={
    "threshold": {"type":"float","min":0.4,"max":0.6,"step":0.02,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    thr = float(p.get("threshold", 0.5))
    model = make_model(p)
    prob = _train_predict_proba(model, df)
    return _to_signal(prob, thr)
