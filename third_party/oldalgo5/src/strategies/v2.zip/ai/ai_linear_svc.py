
import pandas as pd
from ..registry import register
from ._common import _train_predict_proba, _to_signal
from sklearn.svm import LinearSVC

def make_model(p):
    return LinearSVC(C=float(p.get('C',1.0)), dual='auto', random_state=42)

@register("ai_linear_svc", schema={"C": {"type":"float","min":0.1,"max":5.0,"step":0.1,"default":1.0},

    "threshold": {"type":"float","min":0.4,"max":0.6,"step":0.02,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    thr = float(p.get("threshold", 0.5))
    model = make_model(p)
    prob = _train_predict_proba(model, df)
    return _to_signal(prob, thr)
