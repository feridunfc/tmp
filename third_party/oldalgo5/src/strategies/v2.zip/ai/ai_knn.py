
import pandas as pd
from ..registry import register
from ._common import _train_predict_proba, _to_signal
from sklearn.neighbors import KNeighborsClassifier

def make_model(p):
    return KNeighborsClassifier(n_neighbors=int(p.get('n_neighbors',15)))

@register("ai_knn", schema={"n_neighbors": {"type":"int","min":3,"max":50,"step":1,"default":15},

    "threshold": {"type":"float","min":0.4,"max":0.6,"step":0.02,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    thr = float(p.get("threshold", 0.5))
    model = make_model(p)
    prob = _train_predict_proba(model, df)
    return _to_signal(prob, thr)
