import numpy as np
import pandas as pd
from ..base import StrategyBase
from ..field_spec import FieldSpec
from strategies.ml_models.registry import get_model, list_models

class AIUnifiedStrategy(StrategyBase):
    def __init__(self, model: str = "rf", lag_list: str = "1,2,3,5,10", proba_thresh: float = 0.55):
        self.model_name = model
        self.lag_list = [int(x.strip()) for x in str(lag_list).split(",") if x.strip().isdigit()]
        if len(self.lag_list) == 0:
            self.lag_list = [1,2,3,5,10]
        self.thresh = float(proba_thresh)

    @classmethod
    def param_schema(cls):
        return [
            FieldSpec("model", type="select", default="rf", options=list_models() or ["rf","logreg"]),
            FieldSpec("lag_list", type="text", default="1,2,3,5,10"),
            FieldSpec("proba_thresh", type="float", default=0.55),
        ]

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        if df is None or df.empty:
            raise ValueError("AIUnifiedStrategy.prepare(): 'df' empty or None")
        out = df.copy()
        rets = out["close"].pct_change()
        for L in self.lag_list:
            out[f"ret_lag_{L}"] = rets.shift(L)
        out["fwd_ret"] = rets.shift(-1)
        out = out.dropna()
        return out

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        # Train on first 70%, predict on rest (toy example)
        n = len(df)
        split = int(n * 0.7)
        feats = [c for c in df.columns if c.startswith("ret_lag_")]
        X = df[feats].values
        y = (df["fwd_ret"].values > 0).astype(int)

        model = get_model(self.model_name)
        if split < 10:
            # too small; return flat
            return pd.Series(0.0, index=df.index, name="signal")

        model.fit(X[:split], y[:split])
        if hasattr(model, "predict_proba"):
            proba = model.predict_proba(X[split:])[:,1]
        else:
            # fallback
            proba = (model.predict(X[split:]) > 0).astype(float)

        sig_part = np.where(proba >= self.thresh, 1.0, 0.0)
        sig = pd.Series(0.0, index=df.index, name="signal")
        sig.iloc[split:] = sig_part
        return sig
