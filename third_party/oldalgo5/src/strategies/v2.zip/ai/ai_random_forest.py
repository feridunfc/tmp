
import pandas as pd
from ..registry import register
from ._common import _train_predict_proba, _to_signal
from sklearn.ensemble import RandomForestClassifier

def make_model(p):
    return RandomForestClassifier(n_estimators=int(p.get('n_estimators',200)), max_depth=int(p.get('max_depth',6)), random_state=42)

@register("ai_random_forest", schema={"n_estimators": {"type":"int","min":50,"max":400,"step":50,"default":200},
    "max_depth": {"type":"int","min":2,"max":12,"step":1,"default":6},

    "threshold": {"type":"float","min":0.4,"max":0.6,"step":0.02,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    thr = float(p.get("threshold", 0.5))
    model = make_model(p)
    prob = _train_predict_proba(model, df)
    return _to_signal(prob, thr)
