from __future__ import annotations
import pandas as pd
import numpy as np
from ..base import StrategyBase, ParamField

class UnifiedAIStrategy(StrategyBase):
    """Lightweight ML-like momentum model (no heavy deps)."""
    @classmethod
    def param_schema(cls):
        return [
            ParamField("lookback", "int", 30, 5, 300),
            ParamField("threshold", "float", 0.1, 0.0, 5.0),
        ]

    def __init__(self, **params):
        self.params = self.validate_params(params)

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        lb = int(self.params.get("lookback", 30))
        ret = out["close"].pct_change().fillna(0.0)
        out["mom"] = ret.rolling(lb, min_periods=lb).mean()
        out["vol"] = ret.rolling(lb, min_periods=lb).std().replace(0, np.nan)
        out["z"] = out["mom"] / out["vol"]
        return out

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        thr = float(self.params.get("threshold", 0.1))
        z = df["z"].fillna(0.0)
        sig = (z > thr).astype(int) - (z < -thr).astype(int)
        return sig.shift(1).fillna(0.0)
