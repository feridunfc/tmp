
import pandas as pd
from ..registry import register
from ._common import _train_predict_proba, _to_signal
from sklearn.ensemble import AdaBoostClassifier

def make_model(p):
    return AdaBoostClassifier(n_estimators=int(p.get('n_estimators',200)), learning_rate=float(p.get('learning_rate',0.05)), random_state=42)

@register("ai_adaboost", schema={"n_estimators": {"type":"int","min":50,"max":400,"step":50,"default":200},
    "learning_rate": {"type":"float","min":0.01,"max":0.5,"step":0.01,"default":0.05},

    "threshold": {"type":"float","min":0.4,"max":0.6,"step":0.02,"default":0.5}
})
def gen(df: pd.DataFrame, p):
    thr = float(p.get("threshold", 0.5))
    model = make_model(p)
    prob = _train_predict_proba(model, df)
    return _to_signal(prob, thr)
