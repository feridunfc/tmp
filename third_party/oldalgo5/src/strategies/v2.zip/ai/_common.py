
import pandas as pd, numpy as np
from ..registry import register
from ...features.basic import make_basic_features, target_next_up

def _train_predict_proba(model, df: pd.DataFrame):
    X = make_basic_features(df)
    y = target_next_up(df)
    if len(X) < 50:
        return pd.Series(0.5, index=df.index)
    Xtr, ytr = X.iloc[:-1], y.iloc[:-1]
    model.fit(Xtr, ytr)
    try:
        p = model.predict_proba(X)[:,1]
    except Exception:
        try:
            d = model.decision_function(X)
            p = 1/(1+np.exp(-d))
        except Exception:
            p = np.full(len(X), 0.5)
    return pd.Series(p, index=df.index).clip(0,1)

def _to_signal(p: pd.Series, thr: float=0.5):
    return ((p >= float(thr)).astype(int)*2 - 1).rename("signal")
