from __future__ import annotations
import pandas as pd
import numpy as np
from typing import List
from ..registry import register
from ..adapters import proba_to_signal

class _F:
    def __init__(self, name, type, default=None, options=None):
        self.name, self.type, self.default, self.options = name, type, default, options

@register("xgboost_stub")
class XGBoostStubStrategy:
    """Model yeri hazır; şimdilik basit bir proba üreten stub."""
    def __init__(self, th: float = 0.6):
        self.th = float(th)

    @staticmethod
    def param_schema():
        return [ _F("th","float",0.6) ]

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        ret = out["Close"].pct_change().fillna(0.0)
        # basit bir özelliği normalize et
        x = (ret - ret.rolling(50).mean()) / (ret.rolling(50).std() + 1e-9)
        out["feat"] = x.fillna(0.0)
        return out

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        # dummy proba: feat'i sigmoid'a sok
        z = df["feat"].fillna(0.0).values
        p = 1.0/(1.0+np.exp(-z))
        sig_vals = [proba_to_signal(pi, self.th) for pi in p]
        sig = pd.Series(sig_vals, index=df.index, name="signal").astype(int)
        return sig
