from dataclasses import dataclass
from typing import List, Optional, Any

@dataclass
class FieldSpec:
    name: str
    type: str = "text"   # int, float, select, text
    default: Any = ""
    options: Optional[List[Any]] = None
