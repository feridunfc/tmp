# src/algo2/core/strategies/ensemble/regime_voting.py
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import List
from strategies.base import StrategyBase
from strategies.field_spec import FieldSpec


class RegimeAwareVotingStrategy(StrategyBase):
    """
    Basit bir 'rejime duyarlı' ensemble:
    - Trend sinyali: close vs SMA(slow) (momentum)
    - Mean-reversion sinyali: -trend (çok basitleştirilmiş)
    - Rejim belirleme: son vol medyanına göre (düşük vol -> trend; yüksek vol -> sideways varsayıyoruz)
    - Rejime göre ağırlıklar karıştırılır
    NOT: Örnek amaçlı; gerçek projede RSI/ATR/kalite metrikleriyle zenginleştir.
    """

    def __init__(
        self,
        fast: int = 10,
        slow: int = 30,
        vol_lb: int = 20,
        w_trend_bull: float = 0.7,
        w_mr_bull: float = 0.3,
        w_trend_side: float = 0.2,
        w_mr_side: float = 0.8,
    ):
        self.fast = int(fast)
        self.slow = int(slow)
        self.vol_lb = int(vol_lb)
        self.w_trend_bull = float(w_trend_bull)
        self.w_mr_bull = float(w_mr_bull)
        self.w_trend_side = float(w_trend_side)
        self.w_mr_side = float(w_mr_side)

    @staticmethod
    def param_schema() -> List[FieldSpec]:
        return [
            FieldSpec("fast", "int", 10),
            FieldSpec("slow", "int", 30),
            FieldSpec("vol_lb", "int", 20),
            FieldSpec("w_trend_bull", "float", 0.7),
            FieldSpec("w_mr_bull", "float", 0.3),
            FieldSpec("w_trend_side", "float", 0.2),
            FieldSpec("w_mr_side", "float", 0.8),
        ]

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out["sma_fast"] = out["close"].rolling(self.fast, min_periods=1).mean()
        out["sma_slow"] = out["close"].rolling(self.slow, min_periods=1).mean()
        rets = out["close"].pct_change().fillna(0.0)
        out["vol"] = rets.rolling(self.vol_lb, min_periods=1).std()
        return out

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        # Trend sinyali: close > SMA(slow) -> +1, < -> -1
        mom = np.sign(df["close"] - df["sma_slow"]).astype(float)

        # Mean-reversion (aşırı basit): -momentum
        mr = -mom

        # Rejim: vol medyanına göre ayır
        vol = df["vol"].fillna(method="ffill").fillna(0.0)
        thresh = float(vol.rolling(self.vol_lb, min_periods=1).median().iloc[-1]) if len(vol) else 0.0
        # vol düşükse 'bull/trend', yüksekse 'sideways' gibi davranalım
        # (Bar bazında geçiş yapmak yerine tek eşik; istenirse rolling kıyasla dinamik yapılabilir)
        is_trend_regime = vol <= thresh

        w_trend = np.where(is_trend_regime, self.w_trend_bull, self.w_trend_side)
        w_mr = np.where(is_trend_regime, self.w_mr_bull, self.w_mr_side)

        sig = (w_trend * mom) + (w_mr * mr)
        # [-1, 1] aralığına kırp
        sig = np.clip(sig, -1.0, 1.0)
        return pd.Series(sig, index=df.index, name="signal")
