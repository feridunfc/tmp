from __future__ import annotations
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from ..contracts import register_strategy

@register_strategy
class AI_Unified:
    name = "ai_unified"
    def __init__(self, threshold: float=0.55, random_state:int=42):
        self.params = {"threshold": float(threshold)}
        self.model = RandomForestClassifier(n_estimators=300, n_jobs=-1, random_state=random_state)
        self.features: list[str] | None = None

    def prepare(self, df: pd.DataFrame)->pd.DataFrame:
        return df

    def fit(self, X: pd.DataFrame, y: pd.Series):
        cols = [c for c in X.columns if c not in ("close","open","high","low","volume","y","target")]
        if not cols:
            X = X.copy()
            X["sma_10"] = X["close"].rolling(10).mean()
            X["sma_30"] = X["close"].rolling(30).mean()
            cols = ["sma_10","sma_30"]
        self.features = cols
        self.model.fit(X[cols].fillna(0.0), y.values.ravel())
        return self

    def proba(self, X: pd.DataFrame)->pd.Series:
        cols = self.features or [c for c in X.columns if c not in ("close","open","high","low","volume","y","target")]
        p = self.model.predict_proba(X[cols].fillna(0.0))[:,1]
        return pd.Series(p, index=X.index, name="proba")

    def generate_signals(self, df: pd.DataFrame)->pd.Series:
        p = df["proba"] if "proba" in df.columns else pd.Series(0.5, index=df.index)
        up = (p >= self.params["threshold"]).astype(int)
        dn = (p <= (1 - self.params["threshold"])).astype(int) * -1
        sig = (up + dn).clip(-1, 1).shift(1).fillna(0).astype(int)
        return sig.rename("signal_ai_unified")
